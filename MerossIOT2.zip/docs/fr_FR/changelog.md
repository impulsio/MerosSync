# 21/06/2020

- Nouveau format de documentation
- Correction issue#11

# 11/05/2020

- Ajout du support de l'humidificateur
- Reconnection automatique au cloud Meross
- Nouvelle image d'appareils.

# 28/04/2020

- Le refresh d'un équipement n'enlève plus les modifications locales

# 02/03/2020

- Correction bug sur le cycle de mise à jour des puissances

# 23/01/2020

- Correction bug d'identification avec caractère spécial
- Ne perd plus le widget perso lors d'une synchronisation 

# 11/01/2020

- Nouvelle image d'appareils.
- Modification affichage des commandes.
- Déconnection - Connection tous les jours.

# 10/01/2020

- Correction mise à jour de l'IP
- Synchronisation du nom quand mise à jour sur le cloud
- Icone du plugin au bon format pour JEEDOM

# 27/11/2019

- Changement de catégorie du plugin
- Modification du Tout allumer / Tout éteindre des multiprises
- Affichage du mode RGB / Blanc sur les ampoules / veilleuses
- Correction Historique de consommation
- Mise à jour de la documentation

# 25/11/2019

- Optimisation de la gestion des évenements
- Création du fichier de traduction
- Historique de consommation au jour le jour, plus de calcul global

# 19/11/2019

- Première version

> Changelog détaillé :
> <https://github.com/Jeremie-C/plugin-MerossIOT/commits/master>
